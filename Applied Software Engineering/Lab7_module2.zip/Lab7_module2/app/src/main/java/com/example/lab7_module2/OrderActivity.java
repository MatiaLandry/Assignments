package com.example.lab7_module2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class OrderActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_activity);
        //Create an intent
        Intent intent = getIntent();
        //Get the message from the Main Activity
        String message = intent.getStringExtra(MainActivity.MSG);
        // Set text inside textview to message
        TextView textView = findViewById(R.id.orderText);
        textView.setText(message);

    }
    public void goBack(View view){
        finish();
    }
}